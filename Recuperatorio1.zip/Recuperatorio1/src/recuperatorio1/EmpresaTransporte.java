package recuperatorio1;
import java.util.ArrayList;

public class EmpresaTransporte {
    private ArrayList<Viaje> viajes = new ArrayList<>();
    
    public void registrarViaje(Viaje v) {
        viajes.add(v);
    }
    
    public void mostrarViajes() {
        if (viajes.isEmpty()) {
            System.out.println("No hay viajes registrados");
        } else {
            for (Viaje v : viajes) {
                System.out.println(v);
            }
        }
    }
    
    public void ordenarPorCosto() {
        for (int i = 0; i < viajes.size() - 1; i++) {
            for (int j = 0; j < viajes.size() -i -1; j++) {
                if (viajes.get(j).getCostoFinal() > viajes.get(j + 1).getCostoFinal()) {
                    Viaje aux = viajes.get(j);
                    viajes.remove(j);
                    viajes.add(j, viajes.get(j));
                    viajes.remove(j + 1);
                    viajes.add(j + 1, aux);
                }
            }
        }
        // mostrarVehiculos();
    }
    
    public void ordenarPorPasajero() {
        for (int i = 0; i < viajes.size() - 1; i++) {
            for (int j = 0; j < viajes.size() -i -1; j++) {
                if (viajes.get(j).getPasajero().compareToIgnoreCase(viajes.get(j + 1).getPasajero()) > 0) {
                    Viaje aux = viajes.get(j);
                    viajes.remove(j);
                    viajes.add(j, viajes.get(j));
                    viajes.remove(j + 1);
                    viajes.add(j + 1, aux);
                }
            }
        }
        // mostrarVehiculos();
    }
    
    public double calcularTotalRecaudado() {
        double total = 0;
        for (Viaje v : viajes) {
            total += v.getCostoFinal();
        }
        
        return total;
        
    }
}

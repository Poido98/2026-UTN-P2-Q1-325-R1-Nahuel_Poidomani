package recuperatorio1;
import java.util.Scanner;

public class Aplicacion {
    public static void main(String[] args) {
        EmpresaTransporte empresa = new EmpresaTransporte();
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        
        while (opcion != 6) {
            System.out.println("=== MENU DE GESTION DE TRANSPORTE ===");
            System.out.println("1. Registrar viaje");
            System.out.println("2. Mostrar viajes");
            System.out.println("3. Ordenar por costos");
            System.out.println("4. Ordenar por pasajero");
            System.out.println("5. Mostrar total recaudado");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opcion: ");

            while (!sc.hasNextInt()) {
                System.out.println("Error, ingrese un numero");
                sc.next();
            }
            
            opcion = sc.nextInt();
            sc.nextLine();
            
            if (opcion == 1) {
                System.out.print("Nombre pasajero: ");
                String nombre = sc.nextLine();
                    
                System.out.print("Tipo vehiculo (1-Colectivo, 2-Tren, 3-Subte): ");
                int tipoVeh = sc.nextInt();
                sc.nextLine();

                System.out.print("Patente: ");
                String patente = sc.nextLine();
                    
                int capacidad = 0;
                while (capacidad <= 0) {
                    System.out.print("Ingrese capacidad > 0: ");
                        
                    if (sc.hasNextInt()) {
                        capacidad = sc.nextInt();
                        sc.nextLine();
                            
                        if (capacidad <= 0) {
                            System.out.println("Error, la capacidad debe ser mayor a 0");
                        }
                    } else {
                        System.out.println("Error, ingrese un numero");
                        sc.next();
                    }
                }
                    
                System.out.print("Empresa: ");
                String nombreEmpresa = sc.nextLine();
                    
                    
                VehiculoTransporte vehiculo;
                if (tipoVeh == 1) {
                    vehiculo = new Colectivo(patente, capacidad, nombreEmpresa);
                } else if (tipoVeh == 2) {
                    vehiculo = new Tren(patente, capacidad, nombreEmpresa);
                } else if (tipoVeh == 3) {
                    vehiculo = new Subte(patente, capacidad, nombreEmpresa);
                } else {
                    System.out.println("Opcion invalida, se asigna Colectivo por defecto");
                    vehiculo = new Colectivo(patente, capacidad, nombreEmpresa);
                }
                
                System.out.print("Tipo pasaje (1-Comun, 2-Estudiante, 3-Jubilado): ");
                int tipoPas = sc.nextInt();
                sc.nextLine();
                    
                Pasaje pasaje;
                if (tipoPas == 1) {
                    pasaje = new PasajeComun();
                } else if (tipoPas == 2) {
                    pasaje = new PasajeEstudiante();
                } else if (tipoPas == 3) {
                    pasaje = new PasajeEstudiante();
                } else {
                    System.out.println("Opcion invalida, se asigna Pasaje comun por defecto");
                    pasaje = new PasajeComun();
                }
                    
                empresa.registrarViaje(new Viaje(vehiculo, patente, pasaje, capacidad));
            }

            
            
            else if (opcion == 2) {
                empresa.mostrarViajes();
            }
            
            else if (opcion == 3) {
                empresa.ordenarPorCosto();
                empresa.mostrarViajes();
            }
            
            else if (opcion == 4) {
                empresa.ordenarPorPasajero();
                empresa.mostrarViajes();
            }
            
            else if (opcion == 5) {
                System.out.println("Total recaudado: $" + empresa.calcularTotalRecaudado());
            }
            
             else if (opcion == 6) {
                System.out.println("Saliendo...");
            }
             else {
                 System.out.println("Opcion invalida");
             }
        }
    }
}

                
        
    


                    


package recuperatorio1;

public class PasajeEstudiante implements Pasaje {
    
    @Override
    public double calcularCostoFinal(double costoBase) {
        return costoBase * 0.5;
    }
}

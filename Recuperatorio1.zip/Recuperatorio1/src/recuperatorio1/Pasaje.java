package recuperatorio1;

public interface Pasaje {
    
    double calcularCostoFinal(double costoBase);
}







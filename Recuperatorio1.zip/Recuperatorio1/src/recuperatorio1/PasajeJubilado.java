package recuperatorio1;

public class PasajeJubilado implements Pasaje {
    
    @Override
    public double calcularCostoFinal(double costoBase) {
        return costoBase * 0.25;
    }
}

package recuperatorio1;

public class Viaje {
    private VehiculoTransporte vehiculo;
    private String pasajero;
    private Pasaje pasaje;
    private double costoFinal;

    public Viaje(VehiculoTransporte vehiculo, String pasajero, Pasaje pasaje, double CostoFinal) {
        this.vehiculo = vehiculo;
        this.pasajero = (pasajero == null || pasajero.trim().isEmpty()) ? "Sin nombre" : pasajero;
        this.pasaje = pasaje;
        this.costoFinal = pasaje.calcularCostoFinal(vehiculo.calcularCostoBase());
    }

    public String getPasajero() {
        return pasajero;
    }

    public double getCostoFinal() {
        return costoFinal;
    }
    
    @Override
    public String toString() {
        return "Pasajero: " + pasajero + ", Vehiculo: " + vehiculo +
                ", Costo final: $" + costoFinal;
    }
    
    
}

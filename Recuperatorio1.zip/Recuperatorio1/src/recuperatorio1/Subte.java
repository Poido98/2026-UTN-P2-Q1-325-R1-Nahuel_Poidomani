package recuperatorio1;

public class Subte extends VehiculoTransporte{
    
    public Subte (String patente, int capacidad, String empresa) {
        super(patente, capacidad, empresa);
    }
    
    @Override
    public double calcularCostoBase() {
        return 120;
    }
    
    @Override
    public String toString() {
        return "Subte -" + super.toString();
    }
}

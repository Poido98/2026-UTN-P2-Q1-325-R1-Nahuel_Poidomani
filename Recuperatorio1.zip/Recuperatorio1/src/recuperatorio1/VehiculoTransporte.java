package recuperatorio1;

public abstract class VehiculoTransporte {
    private String patente;
    private int capacidad;
    private String empresa;

    public VehiculoTransporte(String patente, int capacidad, String empresa) {
        this.patente = (patente == null || patente.trim().isEmpty()) ? "Sin patente" : patente;
        this.capacidad = (capacidad <= 0) ? 1 : capacidad;
        this.empresa = (empresa == null || empresa.trim().isEmpty()) ? "Generica" : empresa;
    }

    public String getPatente() {
        return patente;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public String getEmpresa() {
        return empresa;
    }
    
    public abstract double calcularCostoBase();
    
    @Override
    public String toString() {
        return "Patente: " + patente + ", Empresa: " + empresa +
                ", Capacidad: " + capacidad;
    }
    
    
}

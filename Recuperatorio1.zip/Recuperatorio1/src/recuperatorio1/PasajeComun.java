
package recuperatorio1;

public class PasajeComun implements Pasaje {
    
    @Override
    public double calcularCostoFinal(double costoBase) {
        return costoBase;
    }
}
